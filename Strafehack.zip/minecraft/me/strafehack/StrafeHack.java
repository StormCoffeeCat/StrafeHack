package me.strafehack;

import java.awt.Font;

import org.apache.logging.log4j.core.util.SystemClock;
import org.lwjgl.input.Keyboard;

import me.strafehack.event.events.EventKey;
import me.strafehack.event.events.EventPreMotionUpdate;
import me.strafehack.event.events.EventUpdate;
import me.strafehack.module.Module;
import me.strafehack.module.modules.render.*;
import me.strafehack.module.settings.BooleanSetting;
import me.strafehack.module.settings.Setting;
import me.strafehack.module.ModuleManager;
import me.strafehack.event.EventManager;
import me.strafehack.event.EventTarget;
import me.strafehack.ui.UIRenderer;
import me.strafehack.ui.hud.HUDManager;
import me.strafehack.utils.TextRenderer;
import net.minecraft.client.Minecraft;

public class StrafeHack {

	public static StrafeHack instance;
	
	public static String Name = "StrafeHack";
	public static String Version = "0.1";
	
	public static UIRenderer uiRenderer;
	public static ModuleManager moduleManager;
	public EventManager eventManager;
	public static HUDManager hudManager;
	
	public TextRenderer textRenderer = new TextRenderer(new Font("SansSerif", Font.PLAIN, 37), true, 5);
	
	public void Init() {
		instance = this;
		FileManager.Init();
		hudManager = HUDManager.getInstance();
		uiRenderer = new UIRenderer();
		moduleManager = new ModuleManager();
		eventManager = new EventManager();
		
		eventManager.register(this);
	}
	
	public void stopClient() {
		eventManager.unregister(this);
	}
	
	public static void onGui() {
		uiRenderer.Draw();
	}

	@EventTarget
	public void onKey(EventKey event) {
		moduleManager.getModules().stream().filter(module -> module.getKey() == event.getKey()).forEach(module -> module.Toggle());
		
		if (event.getKey() == Keyboard.KEY_COMMA) {
			moduleManager = new ModuleManager();
		}
		if (event.getKey() == Keyboard.KEY_PERIOD) {
			
		}
		if (event.getKey() == Keyboard.KEY_M) {
			hudManager.openConfigScreen();
		}
		if (event.getKey() == Keyboard.KEY_K) {
			System.out.println("Saving Module Settings");
			ModuleManager.saveModuleSettings();
		}
	}
	
}
