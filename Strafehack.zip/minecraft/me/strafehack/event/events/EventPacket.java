package me.strafehack.event.events;

import me.strafehack.event.Event;
import net.minecraft.network.Packet;
import net.minecraft.network.status.client.CPacketPing;

public class EventPacket extends Event {

	private Packet packet;
	
	public EventPacket(Packet packet) {
		this.packet = packet;
	}

	public Packet getPacket() {
		return packet;
	}
	
}
