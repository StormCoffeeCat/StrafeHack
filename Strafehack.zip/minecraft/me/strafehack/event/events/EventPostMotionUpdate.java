package me.strafehack.event.events;

import me.strafehack.event.Event;

public class EventPostMotionUpdate extends Event {

}
