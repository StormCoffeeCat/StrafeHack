package me.strafehack.module;

public enum Category {
	Combat("Combat"),
	Movement("Movement"),
	Player("Player"),
	Render("Render"),
	Other("Other");

	public String name;
	Category(String name) {
		this.name = name;
	}
	
	public int moduleIndex;
	
	public static int size(Category c) {
		
		int i = 0;
		for (Module m : ModuleManager.getModules()) {
			if (m.getCategory() == c) {
				i++;
			}
		}
		
		return i;
	}
	
	public static int placeInList(Module module, Category c) {
		int i = 0;
		
		for (Module m : ModuleManager.getModules()) {
			if (m.getName() != "Gui") {
				if (m.getCategory() == c && m != module) {
					i++;
					continue;
				}
				if (m.getCategory() == c && m == module) {
					return i;
				}
			}
		}
		
		return i;
	}
}
