package me.strafehack.module;

import org.lwjgl.input.Keyboard;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import me.strafehack.FileManager;
import me.strafehack.StrafeHack;
import me.strafehack.event.Event;
import me.strafehack.module.settings.BooleanSetting;
import me.strafehack.module.settings.KeybindSetting;
import me.strafehack.module.settings.Setting;
import me.strafehack.ui.hud.ScreenPosition;
import net.minecraft.client.Minecraft;

public class Module {

	private String name;
	private String description;
	private Category category;
	private boolean expanded = false;
	public int index = 0;
	public KeybindSetting keybind = new KeybindSetting(0);
	private ArrayList<Setting> settings = new ArrayList<Setting>();
	
	public Properties properties = new Properties();

	public Properties load() {
		return properties;
	}
	
	public void save() {
		savePropertiesToFile();
	}
	
	private File getFolder() {
		File folder = new File(FileManager.getMODS_DIR(), this.getClass().getSimpleName());
		folder.mkdirs();
		return folder;
	}
	
	private void savePropertiesToFile() {
		FileManager.writeJsonToFile(new File(getFolder(), "Properties.json"), properties);
	}

	private Properties loadPropertiesFromFile() {
		Properties loaded = FileManager.readFromJson(new File(getFolder(), "Properties.json"), Properties.class);
		
		if (loaded == null) {
			loaded = new Properties();
			this.properties = loaded;
			savePropertiesToFile();
		}
		
		return loaded;
	}

	protected Minecraft mc = Minecraft.getMinecraft();
	
	private boolean isInit = false;
	
	public Module(String name, String description, Category category, int keycode) {
		isInit = false;
		if ((new File(getFolder(), "Properties.json").exists())) {
			properties = loadPropertiesFromFile();
		} else {
			isInit = true;
		}
		if (properties.keycode != 0) {
			keybind.code = properties.keycode;
		} else {
			keybind.code = keycode;
			properties.keycode = keycode;
		}
		this.settings.add(keybind);
		if (isInit) {
			this.properties.settings.add(null);
		}
		
		this.name = name;
		this.description = description;
		this.category = category;
		expanded = false;
		index = 0;
	}

	public void addSettings(Setting... settings) {
		this.settings.addAll(Arrays.asList(settings));

		if (isInit) {
			for (Setting s : settings) {
				properties.settings.add(s.value);
			}
		} else {
			System.out.println("- " + name);
			int count = 0;
			for (Setting s : this.settings) {
				if (!(s instanceof KeybindSetting)) {
					s.value = properties.settings.get(count);
					
					if (s instanceof BooleanSetting) {
						System.out.println(s.name + ": " + ((BooleanSetting)s).isEnabled());
					} else {
						System.out.println(s.name + ": " + s.value);
					}
				}
				count++;
			}
		}
		
		save();
	}
	
	public void setKeycode(int code) {
		keybind.code = code;
		properties.keycode = code;
		save();
	}
	
	public String getName() {
		return name;
	}

	public List<Setting> getSettings() {
		return settings;
	}

	
	public Category getCategory() {
		return category;
	}

	public String getDescription() {
		return description;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}
	
	public boolean isEnabled() {
		return properties.enabled;
	}
	
	public void setEnabled(boolean enabled) {
		this.properties.enabled = enabled;
		onToggle();
		if (enabled) {
			onEnable();
		} else {
			onDisable();
		}
	}

	public int getKey() {
		return keybind.code;
	}
	
	public void onEnable() {
		StrafeHack.instance.eventManager.register(this);
	}

	public void onDisable() {
		StrafeHack.instance.eventManager.unregister(this);
	}
	
	public void onToggle() {
		
	}
	
	public void Toggle() {
		setEnabled(!isEnabled());
	}
	
}
