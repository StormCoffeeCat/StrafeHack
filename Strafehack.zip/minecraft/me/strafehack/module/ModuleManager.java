 package me.strafehack.module;

import me.strafehack.event.EventManager;
import me.strafehack.module.modules.combat.*;
import me.strafehack.module.modules.movement.*;
import me.strafehack.module.modules.other.*;
import me.strafehack.module.modules.player.*;
import me.strafehack.module.modules.render.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static ArrayList<Module> modules = new ArrayList<Module>();

    public ModuleManager() {
    	for (Module m : modules) {
    		EventManager.unregister(m);
    	}
    	modules.clear();
    	modules.add(new DefaultModule());
		modules.add(new me.strafehack.module.modules.render.ArrayList());
		modules.add(new TabGui());
		modules.add(new Gui());
		modules.add(new Sprint());;
		modules.add(new Fly());
		modules.add(new NoFall());
		modules.add(new KillAura());
		modules.add(new Velocity());
		modules.add(new KeyboardDisplay());
		modules.add(new Fullbright());
		modules.add(new FpsDisplay());
		modules.add(new FastPlace());
		modules.add(new Step());
		modules.add(new Glide());
		modules.add(new AutoTotem());
		modules.add(new AntiHunger());
		modules.add(new Scaffold());
		
    }

    public static void saveModuleSettings() {
		for (Module m : modules) {
			m.save();
		}
    }
    
	public static List<Module> getModulesByCategory(Category c) {
		List<Module> modules = new ArrayList<Module>();
		for (Module m : ModuleManager.modules) {
			if (m.getCategory() == c) {
				modules.add(m);
			}
		}
		return modules;
	}
	
    public static ArrayList<Module> getModules() {
        return modules;
    }
    
    public static Module getModule(String name) {
        return modules.stream().filter(module -> module.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    
    public static ArrayList<Module> getEnabledModules() {
    	ArrayList<Module> enabledModules = new ArrayList<Module>();
    	for (Module m : modules) {
    		if (m.isEnabled()) {
    			enabledModules.add(m);
    		}
    	}
    	return enabledModules;
    }
}