package me.strafehack.module;

import java.io.File;

import org.lwjgl.input.Keyboard;

import me.strafehack.FileManager;
import me.strafehack.StrafeHack;
import me.strafehack.ui.hud.HUDManager;
import me.strafehack.ui.hud.IRenderer;
import me.strafehack.ui.hud.ScreenPosition;
import net.minecraft.client.Minecraft;

public abstract class ModuleUI extends Module implements IRenderer {

	public ModuleUI(String name, String description, int keyCode) {
		super(name, description, Category.Render, keyCode);
		StrafeHack.hudManager.register(this);
	}

	public final int getLineOffset(ScreenPosition pos, int lineNum) {
		return pos.getAbsoluteY() + getLineOffset(lineNum);
	}
	
	private int getLineOffset(int lineNum) {
		return (Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT + 3) * lineNum;
	}
	
}
