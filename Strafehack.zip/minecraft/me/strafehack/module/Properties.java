package me.strafehack.module;

import java.util.ArrayList;

import me.strafehack.module.settings.KeybindSetting;
import me.strafehack.module.settings.Setting;
import me.strafehack.ui.hud.ScreenPosition;

public class Properties {

	public ArrayList<String> settings = new ArrayList<String>();
	public ScreenPosition pos = new ScreenPosition(0.5, 0.5);
	public boolean enabled = false;
	public int keycode = 0;
	
}
