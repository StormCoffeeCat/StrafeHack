package me.strafehack.module.modules.combat;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.*;
import me.strafehack.event.events.*;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.settings.*;
import me.strafehack.utils.DrawingUtil;
import me.strafehack.utils.InventoryUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class AutoTotem extends Module {

	public AutoTotem() {
		super("Auto Totem", "Automatically moves a totem inside your inventory into your offhand slot", Category.Combat, Keyboard.KEY_NONE);
	}
	
	@EventTarget
	public void onUpdate(EventUpdate event) {
        if (mc.currentScreen == null || mc.currentScreen instanceof GuiInventory) {
        	Item offhand = mc.player.getHeldItemOffhand().getItem();
            if (InventoryUtil.getItemCount(mc.player.inventoryContainer, Items.TOTEM_OF_UNDYING) > 0 && !offhand.equals(Items.TOTEM_OF_UNDYING)) {
            	InventoryUtil.swap(InventoryUtil.getItemSlot(mc.player.inventoryContainer, Items.TOTEM_OF_UNDYING), 45);
            }
        }
    }


}
