package me.strafehack.module.modules.combat;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.events.EventPostMotionUpdate;
import me.strafehack.event.events.EventPreMotionUpdate;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.event.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.util.EnumHand;

public class KillAura extends Module {

	private EntityLivingBase target;
	private long current, last;
	private int delay = 8;
	private float yaw, pitch;
	private boolean others;
	
	public KillAura() {
		super("KillAura", "Automatically attacks entities near you", Category.Combat, Keyboard.KEY_NONE);
	}

	@EventTarget
	public void onPre(EventPreMotionUpdate event) {
		target = getClosest(mc.playerController.getBlockReachDistance());
		if (target == null) {
			return;
		}
		updateTime();
		yaw = mc.player.rotationYaw;
		pitch = mc.player.rotationPitch;
		if (current - last > 1000 / delay) {
			attack(target);
			resetTime();
		}
	}
	
	@EventTarget
	public void onPost(EventPostMotionUpdate event) {
		if (target == null) {
			return;
		}
		mc.player.rotationYaw = yaw;
		mc.player.rotationPitch = pitch;
		
	}
	
	private void attack(Entity entity) {
		mc.player.swingArm(EnumHand.MAIN_HAND);
		mc.playerController.attackEntity(mc.player, entity);
	}
	
	private void updateTime() {
		current = (System.nanoTime() / 1000000L);
	}
	
	private void resetTime() {
		last = (System.nanoTime() / 1000000L);
	}
	
	private EntityLivingBase getClosest(double range) {
		double dist = range;
		EntityLivingBase target = null;
		
		for (Object obj : mc.world.loadedEntityList) {
			Entity entity = (Entity)obj;
			if (entity instanceof EntityLivingBase) {
				EntityLivingBase player = (EntityLivingBase)entity;
				if (canAttack(player)) {
					double currentDist = mc.player.getDistance(player);
					if (currentDist <= dist) {
						dist = currentDist;
						target = player;
					}
				}
			}
		}
		
		return target;
	}
	
	private boolean canAttack(EntityLivingBase player) {
		return player != mc.player && player.isEntityAlive() && mc.player.getDistance(player) <= mc.playerController.getBlockReachDistance() && player.ticksExisted > 30 && !(mc.player.getCooledAttackStrength(0) < 1);
	}
	
}
