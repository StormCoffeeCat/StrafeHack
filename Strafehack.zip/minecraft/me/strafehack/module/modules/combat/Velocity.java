package me.strafehack.module.modules.combat;

import org.lwjgl.input.Keyboard;

import me.strafehack.module.Category;
import me.strafehack.module.Module;

public class Velocity extends Module {

	public Velocity() {
		super("Velocity", "Take no knockback",Category.Combat, Keyboard.KEY_NONE);
	}

}
