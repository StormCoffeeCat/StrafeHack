package me.strafehack.module.modules.movement;

import org.lwjgl.input.Keyboard;

import me.strafehack.StrafeHack;
import me.strafehack.event.events.EventUpdate;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.settings.*;
import me.strafehack.event.EventTarget;

public class Fly extends Module {

	private boolean isFlying;
	private boolean allowFlying;
	
	public NumberSetting flySpeed = new NumberSetting("Fly Speed", 5, 1, 20);
	
	public Fly() {
		super("Fly", "Fly through the air",Category.Movement, Keyboard.KEY_NONE);
		this.addSettings(flySpeed);
	}

	@EventTarget
	public void onUpdate(EventUpdate event) {
		mc.player.capabilities.isFlying = true;
		mc.player.capabilities.setFlySpeed((float)flySpeed.getValue() / 50);
	}
	
	@Override
	public void onEnable() {
		super.onEnable();
		this.isFlying = mc.player.capabilities.isFlying;
		this.allowFlying = mc.player.capabilities.allowFlying;

		mc.player.capabilities.allowFlying = true;
	}

	@Override
	public void onDisable() {
		super.onDisable();
		mc.player.capabilities.allowFlying = allowFlying;
		mc.player.capabilities.isFlying = isFlying;
	}

}
