package me.strafehack.module.modules.movement;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.*;
import me.strafehack.event.events.*;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.settings.*;
import me.strafehack.utils.DrawingUtil;
import net.minecraft.block.material.Material;

public class Glide extends Module {

	public Glide() {
		super("Glide", "Makes you glide slowly when you are in the air", Category.Movement, Keyboard.KEY_NONE);
	}

	@EventTarget
	public void onUpdate(EventPreMotionUpdate event) {
		double oldY = mc.player.motionY;
		float oldJ = mc.player.jumpMovementFactor;
		if (this.isEnabled()) {
			if ((mc.player.motionY < 0.0d) && (mc.player.isAirBorne) && (!mc.player.isInWater()) && (!mc.player.isOnLadder())) {
				if (!mc.player.isInsideOfMaterial(Material.LAVA)) {
					mc.player.motionY = -.125d;
					mc.player.jumpMovementFactor *= 1.12337f;
				}
			}
		} else {
			mc.player.motionY = oldY;
			mc.player.jumpMovementFactor = oldJ;
		}
	}
	
}
