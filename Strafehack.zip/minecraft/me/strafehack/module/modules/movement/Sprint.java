package me.strafehack.module.modules.movement;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.events.EventPreMotionUpdate;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.event.EventTarget;

public class Sprint extends Module {
	
	public Sprint() {
		super("Auto Sprint", "Automatically sprints when walking",Category.Movement, Keyboard.KEY_NONE);
		save();
	}
	
	@EventTarget
	public void onPre(EventPreMotionUpdate event) {
		if (mc.player.movementInput.moveForward > 0) {
			mc.player.setSprinting(true);
		}
	}
	
}
