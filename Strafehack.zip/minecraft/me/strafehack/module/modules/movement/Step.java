package me.strafehack.module.modules.movement;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.*;
import me.strafehack.event.events.*;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.settings.*;
import me.strafehack.utils.DrawingUtil;

public class Step extends Module {

	private NumberSetting stepheight = new NumberSetting("Step Height", 1d, 0.5d, 3d);
	
	public Step() {
		super("Step", "Allows you to instantly step onto higher blocks", Category.Movement, Keyboard.KEY_NONE);
		addSettings(stepheight);
	}
	
	@EventTarget
	public void onMove(EventPreMotionUpdate event) {
		if (isEnabled()) mc.player.stepHeight = (float)stepheight.getValue();
	}
	
	@Override
	public void onDisable() {
		mc.player.stepHeight = 0.5f;
	}

}
