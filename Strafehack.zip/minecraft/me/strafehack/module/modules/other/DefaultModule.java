package me.strafehack.module.modules.other;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.*;
import me.strafehack.event.events.*;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.settings.*;
import me.strafehack.utils.DrawingUtil;

public class DefaultModule extends Module {

	public DefaultModule() {
		super("Default", "Module that contains the default things for a hack", Category.Other, Keyboard.KEY_NONE);
	}

}
