package me.strafehack.module.modules.player;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.*;
import me.strafehack.event.events.*;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.settings.*;
import me.strafehack.utils.DrawingUtil;
import net.minecraft.network.play.client.CPacketEntityAction;

public class AntiHunger extends Module {

	public AntiHunger() {
		super("Anti Hunger", "Makes you get hunger than slower", Category.Player, Keyboard.KEY_NONE);
	}
	
	@EventTarget
	public void onPacket(EventPacket event) {
    	if (event.getPacket() instanceof CPacketEntityAction) {
        	final CPacketEntityAction packet = (CPacketEntityAction)event.getPacket();
            if (packet.getAction() == CPacketEntityAction.Action.START_SPRINTING || packet.getAction() == CPacketEntityAction.Action.STOP_SPRINTING) {
            	event.setCancelled(true);
            }
        }
	}

}
