package me.strafehack.module.modules.player;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.*;
import me.strafehack.event.events.*;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.settings.*;
import me.strafehack.utils.DrawingUtil;

public class FastPlace extends Module {

	public FastPlace() {
		super("FastPlace", "Makes you place blocks insanefly fast", Category.Player, Keyboard.KEY_NONE);
	}
	
	@EventTarget
	public void onUpdate(EventUpdate event) {
		mc.rightClickDelayTimer = 0;
	}

}
