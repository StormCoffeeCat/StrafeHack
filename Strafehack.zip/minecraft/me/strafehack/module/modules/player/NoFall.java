package me.strafehack.module.modules.player;

import org.lwjgl.input.Keyboard;

import me.strafehack.event.events.EventUpdate;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.event.EventTarget;
import net.minecraft.network.play.client.CPacketPlayer;

public class NoFall extends Module {

	public NoFall() {
		super("NoFall", "Take no fall damage",Category.Player, Keyboard.KEY_NONE);
	}

	@EventTarget
	public void onUpdate(EventUpdate event) {
		mc.getConnection().sendPacket(new CPacketPlayer(true));
	}
}
