package me.strafehack.module.modules.render;

import java.util.Comparator;

import org.lwjgl.input.Keyboard;

import me.strafehack.StrafeHack;
import me.strafehack.event.EventTarget;
import me.strafehack.event.events.EventRender2D;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.ModuleManager;
import me.strafehack.utils.DrawingUtil;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;

public class ArrayList extends Module {

	public ArrayList() {
		super("Array List", "Show a list of enabled hacks on the side of the screen", Category.Render, Keyboard.KEY_NONE);
		this.setEnabled(true);
	}
	
	@EventTarget
	public void onRender(EventRender2D event) {
		ScaledResolution sr = new ScaledResolution(mc);
		FontRenderer fr = mc.fontRenderer;
		
		ModuleManager.getModules().sort(Comparator.comparingInt(m -> fr.getStringWidth(((Module)m).getName())).reversed());
		int count = 0;
		for (Module m : StrafeHack.moduleManager.getEnabledModules()) {
			if (m.getName() != getName() && m.getName() != "Gui") {
				double offset = count * (fr.FONT_HEIGHT + 6);
				Gui.drawRect(sr.getScaledWidth() - DrawingUtil.getStringWidth(m.getName()) - 8, (int)offset, sr.getScaledWidth() - DrawingUtil.getStringWidth(m.getName()) - 9, 6 + fr.FONT_HEIGHT + (int)offset, 0xff0090ff);
				Gui.drawRect(sr.getScaledWidth() - DrawingUtil.getStringWidth(m.getName()) - 8, (int)offset, sr.getScaledWidth(), 6 + fr.FONT_HEIGHT + (int)offset, 0x30000000);
				
				DrawingUtil.drawString(m.getName(), sr.getScaledWidth() - DrawingUtil.getStringWidth(m.getName()) - 3, (int)offset + 1, 0xffffff);
				count++;
			}
		}
	}
	
}
