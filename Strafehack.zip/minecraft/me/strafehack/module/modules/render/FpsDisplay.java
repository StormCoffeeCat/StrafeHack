package me.strafehack.module.modules.render;

import org.lwjgl.input.Keyboard;

import me.strafehack.module.ModuleUI;
import me.strafehack.module.settings.BooleanSetting;
import me.strafehack.ui.hud.ScreenPosition;
import me.strafehack.utils.DrawingUtil;

public class FpsDisplay extends ModuleUI {

	private BooleanSetting useBackground = new BooleanSetting("Background", true);
	
	public FpsDisplay() {
		super("FpsDisplay", "Shows a display that shows the fps (frames per second) you have", Keyboard.KEY_NONE);
		addSettings(useBackground);
	}

	@Override
	public int getWidth() {
		return mc.fontRenderer.getStringWidth(mc.getDebugFPS() + " FPS") + 10;
	}

	@Override
	public int getHeight() {
		return mc.fontRenderer.FONT_HEIGHT + 4;
	}

	@Override
	public void render(ScreenPosition pos) {
		if (useBackground.isEnabled()) {
			DrawingUtil.drawRect(pos.getAbsoluteX(), pos.getAbsoluteY(), getWidth(), getHeight(), 0x30000000, 0x00ffffff);
		}
		DrawingUtil.drawCenteredString(mc.getDebugFPS() + " FPS", pos.getAbsoluteX() + (getWidth() / 2), pos.getAbsoluteY(), 0xffffff);
	}

}
