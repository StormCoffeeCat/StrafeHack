package me.strafehack.module.modules.render;

import org.lwjgl.input.Keyboard;

import me.strafehack.module.Category;
import me.strafehack.module.Module;

public class Fullbright extends Module {

	public Fullbright() {
		super("Fullbright", "Allows you to see better in the dark", Category.Render, Keyboard.KEY_NONE);
	}
	
	private float defaultgamma = 0f;
	
	@Override
	public void onEnable() {
		defaultgamma = mc.gameSettings.gammaSetting;
		mc.gameSettings.gammaSetting = 100f;
	}
	
	@Override
	public void onDisable() {
		mc.gameSettings.gammaSetting = defaultgamma;
	}
	
}
