package me.strafehack.module.modules.render;

import org.lwjgl.input.Keyboard;

import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.ModuleManager;
import me.strafehack.module.settings.BooleanSetting;
import me.strafehack.module.settings.Setting;
import me.strafehack.ui.ClickGui;

public class Gui extends Module {

	public BooleanSetting customfont = new BooleanSetting("Custom Font", true);
	public BooleanSetting useshadow = new BooleanSetting("Text Shadow", false);
	
	public Gui() {
		super("Gui", "Setting for guis", Category.Render, Keyboard.KEY_RSHIFT);
		this.addSettings(customfont, useshadow);
	}

	public void ResetModules() {
		for (Module module : ModuleManager.getModules()) {
			for (Setting setting : module.getSettings()) {
				setting.focussed = false;
			}
			module.setExpanded(false);
		}
	}
	
	@Override
	public void onToggle() {
		ResetModules();
		ClickGui gui = new ClickGui();
		gui.allowUserInput = true;
		mc.displayGuiScreen(gui);
	}

}
