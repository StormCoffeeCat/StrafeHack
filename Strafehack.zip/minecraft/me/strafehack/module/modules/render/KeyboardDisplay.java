package me.strafehack.module.modules.render;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import me.strafehack.event.EventTarget;
import me.strafehack.event.events.EventKey;
import me.strafehack.module.Module;
import me.strafehack.module.ModuleUI;
import me.strafehack.module.Properties;
import me.strafehack.ui.hud.ScreenPosition;
import me.strafehack.utils.DrawingUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;

public class KeyboardDisplay extends ModuleUI {

	public KeyboardDisplay() {
		super("Keystrokes", "Shows a keyboard next to your screen", Keyboard.KEY_NONE);
	}

	@Override
	public int getWidth() {
		return 60;
	}

	@Override
	public int getHeight() {
		return 69;
	}

	@Override
	public void render(ScreenPosition pos) {
		final boolean pressedl = Mouse.isButtonDown(0);
		if (pressedl != this.wasPressedl) {
			this.lastPressedl = System.currentTimeMillis();
			this.wasPressedl = pressedl;
			if (pressedl) {
				this.clicksl.add(this.lastPressedl);
			}
		}

		final boolean pressedr = Mouse.isButtonDown(1);
		if (pressedr != this.wasPressedr) {
			this.lastPressedr = System.currentTimeMillis();
			this.wasPressedr = pressedr;
			if (pressedr) {
				this.clicksr.add(this.lastPressedr);
			}
		}
		
		for (Key key : Key.getKeys()) {
			DrawingUtil.drawRect(pos.getAbsoluteX() + key.x, pos.getAbsoluteY() + key.y, key.width, key.height, key.isDown() ? 0x80ffffff : 0x50000000, 0x00ffffff);
			if (key.name == "LMB" || key.name == "RMB") {
				DrawingUtil.drawCenteredString(key.name, pos.getAbsoluteX() + key.x + 14, pos.getAbsoluteY() + key.y - 2, key.isDown() ? 0x000000 : -1);
				DrawingUtil.drawCenteredString(((key.name == "LMB") ? getCpsl() : getCpsr()) + "", pos.getAbsoluteX() + key.x + 14, pos.getAbsoluteY() + key.y + 7, key.isDown() ? 0x000000 : -1);
			} else {
				DrawingUtil.drawCenteredString(key.name, pos.getAbsoluteX() + key.x + 10, pos.getAbsoluteY() + key.y + 3, key.isDown() ? 0x000000 : -1);
			}
			if (key.name == "") {
				DrawingUtil.drawRect(pos.getAbsoluteX() + key.x + 15, pos.getAbsoluteY() + key.y + 5, key.width - 30, 1, key.isDown() ? 0xff000000 : -1, 0x00ffffff);
			}
		}
	}
	
	@Override
	public void renderDummy(ScreenPosition pos) {
		for (Key key : Key.getKeys()) {
			DrawingUtil.drawRect(pos.getAbsoluteX() + key.x, pos.getAbsoluteY() + key.y, key.width, key.height, key.isDown() ? 0x80ffffff : 0x50000000, 0x00ffffff);
			if (key.name == "LMB" || key.name == "RMB") {
				DrawingUtil.drawCenteredString(key.name, pos.getAbsoluteX() + key.x + 14, pos.getAbsoluteY() + key.y - 2, key.isDown() ? 0x000000 : -1);
				DrawingUtil.drawCenteredString("0", pos.getAbsoluteX() + key.x + 14, pos.getAbsoluteY() + key.y + 7, key.isDown() ? 0x000000 : -1);
			} else {
				DrawingUtil.drawCenteredString(key.name, pos.getAbsoluteX() + key.x + 10, pos.getAbsoluteY() + key.y + 3, key.isDown() ? 0x000000 : -1);
			}
			if (key.name == "") {
				DrawingUtil.drawRect(pos.getAbsoluteX() + key.x + 15, pos.getAbsoluteY() + key.y + 5, key.width - 30, 1, key.isDown() ? 0xff000000 : -1, 0x00ffffff);
			}
		}
	}

	private List<Long> clicksl = new ArrayList<Long>();
	private List<Long> clicksr = new ArrayList<Long>();
	private boolean wasPressedl;
	private long lastPressedl;
	private boolean wasPressedr;
	private long lastPressedr;
	
	private int getCpsr() {
		final long time = System.currentTimeMillis();
		this.clicksr.removeIf(aLong -> aLong + 1000 < time);
		return this.clicksr.size();
	}
	
	private int getCpsl() {
		final long time = System.currentTimeMillis();
		this.clicksl.removeIf(aLong -> aLong + 1000 < time);
		return this.clicksl.size();
	}

	private static class Key {
		
		private static final Key W = new Key("W", Minecraft.getMinecraft().gameSettings.keyBindForward, 21, 1, 18, 18);
		private static final Key A = new Key("A", Minecraft.getMinecraft().gameSettings.keyBindLeft, 1, 21, 18, 18);
		private static final Key S = new Key("S", Minecraft.getMinecraft().gameSettings.keyBindBack, 21, 21, 18, 18);
		private static final Key D = new Key("D", Minecraft.getMinecraft().gameSettings.keyBindRight, 41, 21, 18, 18);

		private static final Key Space = new Key("", Minecraft.getMinecraft().gameSettings.keyBindJump, 1, 61, 58, 8);
		
		private static final Key LMB = new Key("LMB", Minecraft.getMinecraft().gameSettings.keyBindAttack, 1, 41, 28, 18);
		private static final Key RMB = new Key("RMB", Minecraft.getMinecraft().gameSettings.keyBindUseItem, 31, 41, 28, 18);

	    private ArrayList<Key> keys = new ArrayList<Key>();
		
		private final String name;
		private final KeyBinding keybind;
		private final int x;
		private final int y;
		private final int width;
		private final int height;
		
		public static ArrayList<Key> getKeys() {
			ArrayList<Key> keys = new ArrayList<Key>();
			keys.add(W);
			keys.add(A);
			keys.add(S);
			keys.add(D);
			keys.add(Space);
			keys.add(LMB);
			keys.add(RMB);
			return keys;
		}
		
		public Key(String name, KeyBinding keybind, int x, int y, int width, int height) {
			this.name = name;
			this.keybind = keybind;
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;
		}
		
		public boolean isDown() {
			return keybind.isKeyDown();
		}
		
		public int getHeight() {
			return height;
		}
		
		public int getWidth() {
			return width;
		}
		
		public int getX() {
			return x;
		}
		
		public int getY() {
			return y;
		}
	}

}
