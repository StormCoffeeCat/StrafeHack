package me.strafehack.module.modules.render;

import java.util.Comparator;

import org.lwjgl.input.Keyboard;

import me.strafehack.StrafeHack;
import me.strafehack.event.EventTarget;
import me.strafehack.event.events.EventKey;
import me.strafehack.event.events.EventRender2D;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.ModuleManager;
import me.strafehack.module.settings.*;
import me.strafehack.utils.DrawingUtil;
import me.strafehack.utils.TextRenderer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;

public class TabGui extends Module {

	public boolean expanded = false;
	public int index = 0;
	
	public TabGui() {
		super("TabGui", "Displays a little gui on the side of the screen where you can toggle hacks",Category.Render, Keyboard.KEY_NONE);
		this.setEnabled(true);
	}

	public static int selectedIndex = 0;
	
	@EventTarget
	public void onRender(EventRender2D event) {
		ScaledResolution sr = new ScaledResolution(mc);
		
		int count = 0;
		for (Category category : Category.values()) {
			double offset = count * (mc.fontRenderer.FONT_HEIGHT + 5);
			Gui.drawRect(13, (int)offset + 47, 80, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0x30000000);
			DrawingUtil.drawString(category.name(), 18, (int)offset + 47, 0xffffff);
			count++;
		}
		double offset = selectedIndex * (mc.fontRenderer.FONT_HEIGHT + 5);
		if (!expanded) {
			Gui.drawRect(13, (int)offset + 47, 14, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0xff0090ff);
		}
		
		if (expanded) {
			count = 0;
			for (Module module : ModuleManager.getModulesByCategory(Category.values()[selectedIndex])) {
				offset = selectedIndex * (mc.fontRenderer.FONT_HEIGHT + 5) + (count * 14);
				Gui.drawRect(80, (int)offset + 47, 147, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0x30000000);
				DrawingUtil.drawString(module.getName(), 85, (int)offset + 47, 0xffffff);
				count++;
			}
			Category selectedCategory = Category.values()[selectedIndex];
			Module module = ModuleManager.getModulesByCategory(selectedCategory).get(selectedCategory.moduleIndex);
			if (!module.isExpanded()) {
				offset = selectedCategory.moduleIndex * (mc.fontRenderer.FONT_HEIGHT + 5) + (selectedIndex * 14);
				Gui.drawRect(80, (int)offset + 47, 81, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0xff0090ff);
			} else {
				count = 0;
				for (Setting setting : module.getSettings()) {
					offset = selectedIndex * (mc.fontRenderer.FONT_HEIGHT + 5) + (count * 14) + (selectedCategory.moduleIndex * 14);
					Gui.drawRect(147, (int)offset + 47, 250, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0x30000000);
					offset = module.index * (mc.fontRenderer.FONT_HEIGHT + 5) + (selectedIndex * 14) + (selectedCategory.moduleIndex * 14);
					Gui.drawRect(147, (int)offset + 47, 148, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0xff0090ff);
					offset = selectedIndex * (mc.fontRenderer.FONT_HEIGHT + 5) + (count * 14) + (selectedCategory.moduleIndex * 14);
				
					if (setting.focussed) {
						drawHorizontalLine(147, 249, (int)offset + 47, 0xff0090ff);
						drawHorizontalLine(147, 249, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0xff0090ff);
						drawVerticalLine(249, (int)offset + 47, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0xff0090ff);
						drawVerticalLine(147, (int)offset + 47, (int)offset + mc.fontRenderer.FONT_HEIGHT + 52, 0xff0090ff);
					}
					
					if (setting instanceof KeybindSetting) {
						KeybindSetting s = ((KeybindSetting)setting);
						DrawingUtil.drawString(s.name + ": " + Keyboard.getKeyName(s.code), 151, (int)offset + 48, 0xffffff);
					}
					if (setting instanceof NumberSetting) {
						NumberSetting s = ((NumberSetting)setting);
						DrawingUtil.drawString(s.name + ": " + s.getValue(), 151, (int)offset + 48, 0xffffff);
					}
					if (setting instanceof ModeSetting) {
						ModeSetting s = ((ModeSetting)setting);
						DrawingUtil.drawString(s.name + ": " + s.getMode(), 151, (int)offset + 48, 0xffffff);
					}
					if (setting instanceof BooleanSetting) {
						BooleanSetting s = ((BooleanSetting)setting);
						DrawingUtil.drawString(s.name + ": " + s.isEnabled(), 151, (int)offset + 48, 0xffffff);
					}
					
					count++;
				}
			}
		}
	}
	

    protected void drawHorizontalLine(int startX, int endX, int y, int color)
    {
        if (endX < startX)
        {
            int i = startX;
            startX = endX;
            endX = i;
        }

        Gui.drawRect(startX, y, endX + 1, y + 1, color);
    }

    protected void drawVerticalLine(int x, int startY, int endY, int color)
    {
        if (endY < startY)
        {
            int i = startY;
            startY = endY;
            endY = i;
        }

        Gui.drawRect(x, startY + 1, x + 1, endY, color);
    }
    
	public void ResetFocussed() {
		for (Module module : ModuleManager.getModules()) {
			for (Setting setting : module.getSettings()) {
				setting.focussed = false;
			}
		}
	}
	
	@EventTarget
	public void onKey(EventKey event) {
		Category selectedCategory = Category.values()[selectedIndex];
		Module module = ModuleManager.getModulesByCategory(selectedCategory).get(selectedCategory.moduleIndex);
		Setting setting = module.getSettings().get(module.index);
		if (!expanded) {
			if (event.getKey() == Keyboard.KEY_UP && selectedIndex > 0) {
				selectedIndex--;
			}
			if (event.getKey() == Keyboard.KEY_DOWN && selectedIndex < Category.values().length - 1) {
				selectedIndex++;
			}
		} else {
			if (event.getKey() == Keyboard.KEY_UP && selectedCategory.moduleIndex > 0 && !module.isExpanded()) {
				selectedCategory.moduleIndex--;
			}
			if (event.getKey() == Keyboard.KEY_DOWN && selectedCategory.moduleIndex < ModuleManager.getModulesByCategory(Category.values()[selectedIndex]).size() - 1 && !module.isExpanded()) {
				selectedCategory.moduleIndex++;
			}
			if (event.getKey() == Keyboard.KEY_RETURN && !module.isExpanded()) {
				module.Toggle();
				module.properties.settings.set(module.getSettings().indexOf(setting), setting.value);
				ModuleManager.saveModuleSettings();
			}
			if (module.isExpanded()) {
				if (event.getKey() == Keyboard.KEY_UP && expanded && module.index > 0) {
					module.index--;
				}
				if (event.getKey() == Keyboard.KEY_DOWN && expanded && module.index < module.getSettings().size() - 1) {
					module.index++;
				}
				if (event.getKey() == Keyboard.KEY_RETURN) {
					if (!(setting instanceof BooleanSetting)) {
						boolean f = setting.focussed;
						ResetFocussed();
						setting.focussed = !f;
					} else if (setting instanceof BooleanSetting) {
						((BooleanSetting)setting).Toggle();
						module.properties.settings.set(module.getSettings().indexOf(setting), setting.value);
						ModuleManager.saveModuleSettings();
					}
				}
				if (setting instanceof NumberSetting && setting.focussed) {
					NumberSetting s = ((NumberSetting)setting);
					if (event.getKey() == Keyboard.KEY_LEFT) {
						s.setValue(s.getValue() - 1);
						module.properties.settings.set(module.getSettings().indexOf(setting), setting.value);
						ModuleManager.saveModuleSettings();
					}
					if (event.getKey() == Keyboard.KEY_RIGHT) {
						s.setValue(s.getValue() + 1);
						module.properties.settings.set(module.getSettings().indexOf(setting), setting.value);
						ModuleManager.saveModuleSettings();
					}
				}
				if (setting.focussed) {
					if (setting instanceof KeybindSetting && event.getKey() != Keyboard.KEY_RETURN) {
						if (event.getKey() == Keyboard.KEY_BACK) {
							((KeybindSetting) setting).code = Keyboard.KEY_NONE;
							setting.focussed = false;
						} else {
							((KeybindSetting) setting).code = event.getKey();
							setting.focussed = false;
						}
					}
					if (setting instanceof ModeSetting) {
						if (event.getKey() == Keyboard.KEY_LEFT) {
							((ModeSetting) setting).cycle(-1);
							module.properties.settings.set(module.getSettings().indexOf(setting), setting.value);
							ModuleManager.saveModuleSettings();
						} else if (event.getKey() == Keyboard.KEY_RIGHT) {
							((ModeSetting) setting).cycle(1);
							module.properties.settings.set(module.getSettings().indexOf(setting), setting.value);
							ModuleManager.saveModuleSettings();
						}
					}
				}
				
			}
		}
		if (event.getKey() == Keyboard.KEY_RIGHT) {
			if (expanded) {
				module.setExpanded(true);
			} else {
				expanded = true;
			}
		}
		if (event.getKey() == Keyboard.KEY_LEFT && !setting.focussed) {
			if (module.isExpanded() && expanded) {
				module.setExpanded(false);
			} else {
				expanded = false;
				module.setExpanded(false);
			}
		}
	}
	
}
