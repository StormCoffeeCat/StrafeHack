package me.strafehack.module.settings;

import net.minecraft.client.gui.GuiScreen;

public class BooleanSetting extends Setting {

	public BooleanSetting(String name, boolean enabled) {
		this.name = name;
		setEnabled(enabled);
	}

	public boolean isEnabled() {
		return value.startsWith("true");
	}

	public void setEnabled(boolean enabled) {
		value = enabled + "";
	}
	
	public void Toggle() {
		if (isEnabled()) {
			value = "false";
		} else {
			value = "true";
		}
	}
	
}
