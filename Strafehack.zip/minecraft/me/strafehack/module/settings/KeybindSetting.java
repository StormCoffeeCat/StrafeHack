package me.strafehack.module.settings;

public class KeybindSetting extends Setting {

	public int code;
	
	public KeybindSetting(int code) {
		this.name = "Keybind";
		this.code = code;
	}

}
