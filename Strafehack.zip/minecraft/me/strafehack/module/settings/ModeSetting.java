package me.strafehack.module.settings;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {

	public List<String> modes;
	
	public ModeSetting(String name, String defaultMode, String... modes) {
		this.name = name;
		this.modes = Arrays.asList(modes);
		value = this.modes.indexOf(defaultMode) + "";
	}
	
	public String getMode() {
		return modes.get(Integer.parseInt(value));
	}
	
	public boolean is(String mode) {
		return value == modes.indexOf(mode) + "";
	}
	
	public void cycle(int amount) {
		if (Integer.parseInt(value) + amount < modes.size() && Integer.parseInt(value) + amount > -1) {
			value = Integer.parseInt(value) + amount + "";
		}
	}
	
}
