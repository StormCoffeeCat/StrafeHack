package me.strafehack.module.settings;

public class NumberSetting extends Setting {

	private double minimum, maximum;

	public NumberSetting(String name, double value, double minimum, double maximum) {
		this.name = name;
		this.value = value + "";
		this.minimum = minimum;
		this.maximum = maximum;
	}
	
	public double getValue() {
		return Double.parseDouble(value);
	}

	public void setValue(double value) {
		this.value = Math.round(Math.max(minimum, Math.min(maximum, value))) + "";
	}
	
	public void increment(boolean positive) {
		setValue(getValue() + (positive ? 1 : -1));
	}

	public double getMinimum() {
		return minimum;
	}

	public void setMinimum(double minimum) {
		this.minimum = minimum;
	}

	public double getMaximum() {
		return maximum;
	}

	public void setMaximum(double maximum) {
		this.maximum = maximum;
	}

}
