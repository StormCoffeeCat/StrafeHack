package me.strafehack.module.settings;

public class Setting {

	public String name;
	public boolean focussed;
	public String value;
	
}
