package me.strafehack.ui;

import me.strafehack.module.ModuleManager;
import me.strafehack.module.settings.*;
import me.strafehack.module.settings.Setting;
import me.strafehack.utils.DrawingUtil;

import java.io.IOException;
import java.util.List;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import me.strafehack.StrafeHack;
import me.strafehack.event.EventTarget;
import me.strafehack.event.events.EventKey;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class ClickGui extends GuiScreen {

	private Minecraft mc = Minecraft.getMinecraft();
	
	private int key = -1;
	
	@Override
	public void keyTyped(char typedChar, int keyCode) throws IOException{
		super.keyTyped(typedChar, keyCode);
		for (Module module : ModuleManager.getModules()) {
			if (module.isExpanded()) {
				for (Setting setting : module.getSettings()) {
					if (setting instanceof KeybindSetting) {
						if (setting.focussed) {
							if (keyCode == Keyboard.KEY_ESCAPE) {
								setting.focussed = false;
							} else if (keyCode == Keyboard.KEY_BACK) {
								((KeybindSetting)setting).code = 0;
								setting.focussed = false;
							} else {
								module.setKeycode(keyCode);
								setting.focussed = false;
							}
						}
					} else if (setting instanceof BooleanSetting) {
						BooleanSetting s = ((BooleanSetting)setting);
						if (s.focussed) {
							if (keyCode == Keyboard.KEY_F) {
								s.setEnabled(false);
								setting.focussed = false;
								module.properties.settings.set(module.getSettings().indexOf(s), s.isEnabled() + "");
							} else if (keyCode == Keyboard.KEY_T) {
								s.setEnabled(true);
								setting.focussed = false;
								module.properties.settings.set(module.getSettings().indexOf(s), s.isEnabled() + "");
							}
						}
					} else if (setting instanceof ModeSetting) {
						ModeSetting s = ((ModeSetting)setting);
						if (s.focussed) {
							if (keyCode == Keyboard.KEY_LEFT) {
								s.cycle(-1);
								module.properties.settings.set(module.getSettings().indexOf(s), s.value);
							} else if (keyCode == Keyboard.KEY_RIGHT) {
								s.cycle(1);
								module.properties.settings.set(module.getSettings().indexOf(s), s.value);
							}
						}
					}
				}
			}
		}
	}

	public void ResetFocussed() {
		for (Module module : ModuleManager.getModules()) {
			for (Setting setting : module.getSettings()) {
				setting.focussed = false;
			}
		}
	}
	
	public void ResetModules() {
		for (Module module : ModuleManager.getModules()) {
			for (Setting setting : module.getSettings()) {
				setting.focussed = false;
			}
			module.setExpanded(false);
		}
	}
	
    public static int returnDarkerColor(int color){
        float ratio = 1.0f - 0.075f;
        int a = (color >> 24) & 0xFF;
        int r = (int) (((color >> 16) & 0xFF) * ratio);
        int g = (int) (((color >> 8) & 0xFF) * ratio);
        int b = (int) ((color & 0xFF) * ratio);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks)  {
		Gui.drawRect(10, 0, 80, 14, 0xff0090ff);
		Gui.drawRect(90, 0, 160, 14, 0xff0090ff);
		Gui.drawRect(170, 0, 240, 14, 0xff0090ff);
		Gui.drawRect(250, 0, 320, 14, 0xff0090ff);
		Gui.drawRect(330, 0, 400, 14, 0xff0090ff);

		Gui.drawRect(10, 13, 80, 14, 0xffffffff);
		Gui.drawRect(90, 13, 160, 14, 0xffffffff);
		Gui.drawRect(170, 13, 240, 14, 0xffffffff);
		Gui.drawRect(250, 13, 320, 14, 0xffffffff);
		Gui.drawRect(330, 13, 400, 14, 0xffffffff);
		
		int count = 0;
		for (Category category : Category.values()) {
			DrawingUtil.drawCenteredString(category.name(), 45 + (count * 80), -1, 0xffffff);
			count++;
		}

		super.drawScreen(mouseX, mouseY, partialTicks);
		
		for (Module module : ModuleManager.getModules()) {
			if (module.isExpanded()) {
				int settingcount = 0;
				for (Setting setting : module.getSettings()) {
					int left = placeForHackX(module) + 70;
					int top = placeForHackY(module) + (settingcount * 14);
					int longestwidth = 0;
					for (Setting set : module.getSettings()) {
						String string = (set instanceof BooleanSetting) ? set.name + ": " + ((BooleanSetting)set).value : (set instanceof NumberSetting) ? set.name + ": " + ((NumberSetting)set).getValue() : (set instanceof KeybindSetting) ? set.name + ": " + Keyboard.getKeyName(((KeybindSetting)set).code) : (set instanceof ModeSetting) ? set.name + ((ModeSetting)set).getMode() : "";
						if (DrawingUtil.getStringWidth(string) > longestwidth) {
							longestwidth = DrawingUtil.getStringWidth(string);
						}
					}
					int right = placeForHackX(module) + longestwidth + 75;
					int bottom = placeForHackY(module) + 14 + (settingcount * 14);
					if (setting.focussed) {
						Gui.drawRect(left, top, right, bottom, 0x80000000);
						
	            		this.drawHorizontalLine(left, right - 1, top, 0xff0090ff);
	            		this.drawHorizontalLine(left, right - 1, bottom - 1, 0xff0090ff);
	            		this.drawVerticalLine(left, top, bottom, 0xff0090ff);
	            		this.drawVerticalLine(right - 1, top, bottom, 0xff0090ff);
	            		
					} else {
						Gui.drawRect(left, top, right, bottom, returnDarkerColor(0x80000000));
					}
					if (setting instanceof NumberSetting) {
						NumberSetting s = (NumberSetting)setting;
						if (Mouse.isButtonDown(0) && mouseX > left && mouseY > top && mouseX < right && mouseY < bottom) {
							int current = mouseX - left;
							int width = right - left;
							
							s.setValue((double)current / (double)width * ((double)s.getMaximum() + (double)s.getMinimum()));
							module.properties.settings.set(module.getSettings().indexOf(s), s.getValue() + "");
						}
						Gui.drawRect(left, bottom - 1, (int)(((double)s.getValue() / (double)s.getMaximum()) * (double)(right - left)) + left, bottom, 0xffffffff);
						
						DrawingUtil.drawString(s.name + ": " + s.getValue(), placeForHackX(module) + 72, placeForHackY(module) + (settingcount * 14), 0xffffff);
					} else if (setting instanceof KeybindSetting) {
						KeybindSetting s = (KeybindSetting)setting;
						if (Mouse.isButtonDown(0) && mouseX > left && mouseY > top && mouseX < right && mouseY < bottom) {
							ResetFocussed();
							s.focussed = true;
						}
						if (s.code == 0) {
							DrawingUtil.drawString(s.name + ": None", placeForHackX(module) + 72, placeForHackY(module) + (settingcount * 14), 0xffffff);
						} else {
							DrawingUtil.drawString(s.name + ": " + Keyboard.getKeyName(s.code), placeForHackX(module) + 72, placeForHackY(module) + (settingcount * 14), 0xffffff);
						}
					} else if (setting instanceof BooleanSetting) {
						BooleanSetting s = ((BooleanSetting)setting);
						if (Mouse.isButtonDown(0) && mouseX > left && mouseY > top && mouseX < right && mouseY < bottom) {
							ResetFocussed();
							s.focussed = true;
						}
						DrawingUtil.drawString(s.name + ": " + s.isEnabled(), placeForHackX(module) + 72, placeForHackY(module) + (settingcount * 14), 0xffffff);
					} else if (setting instanceof ModeSetting) {
						ModeSetting s = ((ModeSetting)setting);
						if (Mouse.isButtonDown(0) && mouseX > left && mouseY > top && mouseX < right && mouseY < bottom) {
							ResetFocussed();
							s.focussed = true;
						}
						DrawingUtil.drawString(s.name + ": " + s.getMode(), placeForHackX(module) + 72, placeForHackY(module) + (settingcount * 14), 0xffffff);
					}
					settingcount++;
				}
			}
		}
		
		for (GuiButton guibutton : buttonList) {
			if (guibutton.hovered) {
				for (Module module : ModuleManager.getModules()) {
	        		if (guibutton.displayString == module.getName()) {
	        			Gui.drawRect(mouseX, mouseY + 10, mouseX + DrawingUtil.getStringWidth(module.getDescription()) + 4, mouseY + mc.fontRenderer.FONT_HEIGHT + 12, 0x80000000);
	        			DrawingUtil.drawString(module.getDescription(), mouseX + 2, mouseY + 9, 0xffffff);
	        		}
	        	}
			}
		}
		
	}

	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}
	
	public int placeForHackY(Module m) {
		return Category.placeInList(m, m.getCategory()) * 14 + 14;
	}

	public int placeForHackX(Module m) {
		if (m.getCategory() == Category.Combat) return 10;
		if (m.getCategory() == Category.Movement) return 90;
		if (m.getCategory() == Category.Player) return 170;
		if (m.getCategory() == Category.Render) return 250;
		if (m.getCategory() == Category.Other) return 330;
		
		return 0;
	}
	
	@Override
	public void initGui() {
		int count = 1;
		for (Module module : ModuleManager.getModules()) {
			buttonList.add(new GuiButton(count, placeForHackX(module), placeForHackY(module), 70, 14, module.getName(), 0x30000000, 0xff0090ff));
			count++;
		}
	}

	@Override
	public void onGuiClosed() {
		ModuleManager.saveModuleSettings();
		ResetModules();
	}
	
	@Override
	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		for (int i = 0; i < this.buttonList.size(); ++i)
        {
            GuiButton guibutton = this.buttonList.get(i);

            if (guibutton.mousePressed(this.mc, mouseX, mouseY))
            {
	            int count = 1;
	        	for (Module module : ModuleManager.getModules()) {
	        		if (guibutton.id == count) {
	        	        if (mouseButton == 0) {
	        	           	module.Toggle();
	        	        } else if (mouseButton == 1) {
	        	           	for (Setting s : module.getSettings()) {
	        	           		s.focussed = false;
	        	          	}
	        	         	module.setExpanded(!module.isExpanded());
	        	        }
	        		}
	        		count++;
	        	}
            }
        }
	}
	
}

