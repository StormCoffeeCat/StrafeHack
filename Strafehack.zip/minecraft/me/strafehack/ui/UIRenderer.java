package me.strafehack.ui;

import java.awt.Font;
import java.util.Comparator;

import me.strafehack.StrafeHack;
import me.strafehack.module.Category;
import me.strafehack.module.Module;
import me.strafehack.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

public class UIRenderer extends Gui {
	
	private Minecraft mc = Minecraft.getMinecraft();
	
	public static int selectedIndex = 0;

	public void Draw() {
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.disableAlpha();
        GlStateManager.color(255, 255, 255);
		mc.getTextureManager().bindTexture(new ResourceLocation("assets/logo.png"));
		this.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, 30, 30, 30.0f, 30.0f);
		GlStateManager.popMatrix();
	}
	
}
