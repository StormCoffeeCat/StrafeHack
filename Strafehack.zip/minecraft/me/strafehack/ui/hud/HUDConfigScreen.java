package me.strafehack.ui.hud;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Optional;
import java.util.function.Predicate;

import org.lwjgl.input.Keyboard;

import me.strafehack.module.ModuleManager;
import me.strafehack.module.Properties;
import me.strafehack.utils.DrawingUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

public class HUDConfigScreen extends GuiScreen {

	private final HashMap<IRenderer, Properties> renderers = new HashMap<IRenderer, Properties>();
	
	private Optional<IRenderer> selectedRenderer = Optional.empty();
	
	private int prevX, prevY;
	
	public HUDConfigScreen(HUDManager api) {
		Collection<IRenderer> registeredRenderers = api.getRegistereRenderers();
		
		for (IRenderer renderer : registeredRenderers) {
			if (!renderer.isEnabled()) {
				continue;
			}
			Properties properties = renderer.load();
			
			if (properties.pos == null) {
				properties.pos = ScreenPosition.fromRelativePosition(0.5, 0.5);
			}
			adjustBounds(renderer, properties.pos);
			this.renderers.put(renderer, properties);
		}
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		super.drawDefaultBackground();
		final float zBackup = this.zLevel;
		this.zLevel = 200;

		DrawingUtil.drawRect(0, 0, this.width - 1, this.height - 1, 0x00ffffff, 0xffff0000);
		
		for (IRenderer renderer : renderers.keySet()) {
			Properties properties = renderers.get(renderer);
			renderer.renderDummy(properties.pos);
			DrawingUtil.drawRect(properties.pos.getAbsoluteX() - 2, properties.pos.getAbsoluteY(), renderer.getWidth() + 2, renderer.getHeight(), 0x00ffffff, 0xff0090ff);
		}
		
		this.zLevel = zBackup;
	}

	private void drawHollowRect(int x, int y, int width, int height, int color) {
		this.drawHorizontalLine(x, x + width, y, color);
		this.drawHorizontalLine(x, x + width, y + height, color);
		this.drawVerticalLine(x, y, y + height, color);
		this.drawVerticalLine(x + width, y, y + height, color);
	}
	
	@Override
	protected void keyTyped(char typedChar, int keyCode) throws IOException {
		if (keyCode == Keyboard.KEY_ESCAPE) {
			renderers.entrySet().forEach((entry) -> {
				entry.getKey().save();
			});
			this.mc.displayGuiScreen(null);
		}
	}
	
	@Override
	protected void mouseClickMove(int x, int y, int button, long time) {
		if (selectedRenderer.isPresent()) {
			moveSelectedRendererBy(x - prevX, y - prevY);
		}
		this.prevX = x;
		this.prevY = y;
	}

	private void moveSelectedRendererBy(int x, int y) {
		IRenderer renderer = selectedRenderer.get();
		Properties properties = renderers.get(renderer);
		
		properties.pos.setAbsolute(properties.pos.getAbsoluteX() + x, properties.pos.getAbsoluteY() + y);
		adjustBounds(renderer, properties.pos);
	}
	
	@Override
	public void onGuiClosed() {
		for (IRenderer renderer : renderers.keySet()) {
			renderer.save();
		}

		ModuleManager.saveModuleSettings();
	}
	
	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}
	
	private void adjustBounds(IRenderer renderer, ScreenPosition pos) {
		ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
		int screenWidth = res.getScaledWidth();
		int screenHeight = res.getScaledHeight();
		
		int absoluteX = Math.max(0, Math.min(pos.getAbsoluteX(), Math.max(screenWidth - renderer.getWidth(), 0)));
		int absoluteY = Math.max(0, Math.min(pos.getAbsoluteY(), Math.max(screenHeight - renderer.getHeight(), 0)));
		
		pos.setAbsolute(absoluteX, absoluteY);
	}
	
	@Override
	protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
		this.prevX = mouseX;
		this.prevY = mouseY;
		
		loadMouseOver(mouseX, mouseY);
	}

	private void loadMouseOver(int mouseX, int mouseY) {
		this.selectedRenderer = renderers.keySet().stream().filter(new MouseOverFinder(mouseX, mouseY)).findFirst();
	}
	
	private class MouseOverFinder implements Predicate<IRenderer> {

		private int mouseX, mouseY;
		
		public MouseOverFinder(int mouseX, int mouseY) {
			this.mouseX = mouseX;
			this.mouseY = mouseY;
		}
		
		@Override
		public boolean test(IRenderer renderer) {
			
			Properties properties = renderers.get(renderer);
			int absoluteX = properties.pos.getAbsoluteX();
			int absoluteY = properties.pos.getAbsoluteY();
			
			if (mouseX >= absoluteX && mouseX <= absoluteX + renderer.getWidth()) {
				if (mouseY >= absoluteY && mouseY <= absoluteY + renderer.getHeight()) {
					return true;
				}
			}
			
			return false;
		}
		
	}
	
}
