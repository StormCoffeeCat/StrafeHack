package me.strafehack.ui.hud;

import me.strafehack.module.Properties;

public interface IRenderConfig {

	public void save();
	public Properties load();
	
}
