package net.minecraft.advancements;

import net.minecraft.util.ResourceLocation;

public interface ICriterionInstance
{
    ResourceLocation getId();
}
