package net.minecraft.client.gui;

public interface GuiYesNoCallback
{
    void confirmClicked(boolean result, int id);
}
